Drop signed/release installer files in this folder using these names:
Windows: 3P-Compressor-Setup.exe
Linux:   3P-Compressor-Linux.AppImage (or .deb; update index.html href)
macOS:   3P-Compressor-macOS.dmg

This source bundle contains the Windows GUI source and portable engine header,
but no built Linux/macOS GUI installers. Do not publish placeholder binaries.
