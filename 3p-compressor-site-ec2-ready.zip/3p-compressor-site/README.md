# 3P Compressor website

Deployable Node.js website for the portable C++17 3P compression engine. It includes an online upload service, desktop release links, pricing, and a direct contact email link. The contact address is a regular mailto link; the site does not send or forward contact messages from its server and needs no SMTP credentials.

## Run locally

Requirements: Node.js 20+ and a C++17 compiler (g++ on Linux/macOS; MinGW-w64/MSYS2 g++ on Windows).

```sh
npm install
g++ -std=c++17 -O3 -pthread p3cli.cpp -o p3cli
cp .env.example .env
npm start
```

On Windows, build the server-side compressor before starting the site. Open the x64 Native Tools Command Prompt for Visual Studio/Build Tools, change to the website folder, and run `build-p3cli-msvc.bat`. MinGW users can run `build-p3cli.bat` or `npm run build:compressor:windows`. The resulting binary belongs beside `server.js`; alternatively set `P3CLI` to its path.

Open http://localhost:3000. Regular files compress to .3p; .3p files decompress to their original name and format. Online jobs are limited to 100 MB by default, with at most two concurrent jobs. Set `MAX_UPLOAD_MB` to adjust the upload limit. The service removes temporary input and output after sending the download.

The public contact address is `projectlowber@gmail.com`, displayed as a clickable email link. Visitors send messages using their own email app. No SMTP credentials, email forwarding service, or contact form backend is used.

## Quick deploy on Amazon Linux 2023

See [EC2-QUICKSTART.md](EC2-QUICKSTART.md) for setup commands and the Linux compressor build. The site does not need SMTP configuration.

## Add desktop releases

Copy release binaries into `downloads/` with these exact names: `3P-Compressor-Setup.exe`, `3P-Compressor-Linux.AppImage`, and `3P-Compressor-macOS.dmg`. The source bundle does not include release installers. Until an installer is added, the page labels that platform’s link “Release coming soon.” Mobile browsers see the online compressor and a note to visit on a desktop; installer cards are hidden.

## Deploy with Docker

```sh
docker build -t 3p-compressor-site .
docker run --rm -p 3000:3000 3p-compressor-site
```

Provide a persistent volume for `downloads/` if release assets are managed outside the image. Put the service behind HTTPS and configure the reverse proxy request limit to at least the chosen `MAX_UPLOAD_MB`. The compressor uses temporary disk space for input and output, so provision adequate disk, memory, and CPU.
