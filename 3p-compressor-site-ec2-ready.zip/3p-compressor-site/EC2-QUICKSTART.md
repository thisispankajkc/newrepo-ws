# EC2 quick start (Amazon Linux 2023)

Upload and extract `3p-compressor-site-ec2-ready.zip`:

```bash
sudo mkdir -p /var/www/website
cd /var/www/website
unzip -o 3p-compressor-site-ec2-ready.zip
cd /var/www/website/3p-compressor-site
```

Install Node.js, the compiler, and Nginx, then build the Linux compressor:

```bash
sudo dnf install -y nodejs24 nodejs24-npm gcc-c++ make nginx
npm-24 install --omit=dev
g++ -std=c++17 -O3 -pthread p3cli.cpp -o p3cli
chmod 755 p3cli
```

Linux does not use Windows `.bat` files. The website’s online compressor runs the `p3cli` binary built above. No SMTP configuration is needed; the contact section links directly to `projectlowber@gmail.com`.

Create the site environment file (no email credentials are required):

```bash
cp .env.example .env   # skip if .env already exists
nano .env              # set PORT/MAX_UPLOAD_MB if needed
chmod 600 .env
```

Create `/etc/systemd/system/3p-compressor.service`:

```ini
[Unit]
Description=3P Compressor website
After=network.target

[Service]
Type=simple
User=ec2-user
WorkingDirectory=/var/www/website/3p-compressor-site
EnvironmentFile=/var/www/website/3p-compressor-site/.env
ExecStart=/usr/bin/node-24 /var/www/website/3p-compressor-site/server.js
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Start and inspect the site service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now 3p-compressor
sudo systemctl status 3p-compressor --no-pager
sudo journalctl -u 3p-compressor -n 80 --no-pager
```

Configure Nginx to proxy to `http://127.0.0.1:3000` and allow request bodies up to `100m` (or the configured `MAX_UPLOAD_MB`). Permit inbound HTTP/HTTPS in the EC2 security group.
